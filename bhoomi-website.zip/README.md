# Bhoomi Solutions Website & Generative AI Studio

This repository contains the complete custom web application for **Bhoomi Solutions Ltd** (`www.bhoomisolutionsltd.com`), built with modern HTML5, CSS3, and JavaScript following the exact colors, logo, typography, and interactive headers from your design.

---

## 🚀 How to Preview & Analyze Locally

To launch and preview your website and test all Generative AI demos locally:

1. Open PowerShell or Command Prompt in this folder:
   ```bash
   cd C:\Users\imsra\.gemini\antigravity\scratch\custom-website
   ```
2. Run a local web server using Python:
   ```bash
   python -m http.server 3000
   ```
3. Open your browser at:
   👉 **`http://localhost:3000`**

---

## 🤖 Generative AI Demo Showcase Features

When you click **"Watch Demo"** anywhere on the site (Hero section, navigation, industry cards, or floating bottom-right beacon), the **Bhoomi GenAI & Agentic Studio** opens with:

1. **5 Interactive Multi-Agent Industry Scenarios**:
   - **Customer Support Agent**: Autonomous RMA replacement processing, warranty verification, and CRM sync.
   - **Financial Document Intelligence**: EBITDA extraction, Debt-to-Equity computation, and SOX audit verification.
   - **Clinical Triage & Patient Care**: HIPAA-compliant Emergency Severity Index (ESI) triage and EHR alert dispatching.
   - **Conversational Commerce & AI Stylist**: Catalog search, outfit bundling, and live inventory locking.
   - **Autonomous DevOps & SQL Generator**: Natural language to PostgreSQL queries with syntax highlighting and query plan analytics.
2. **Chain-of-Thought (CoT) Reasoning Engine**: Step-by-step thinking breakdown (NLP Intent $\rightarrow$ Vector RAG $\rightarrow$ Tool Invocation $\rightarrow$ Synthesis).
3. **Live Tool Execution Sandbox**: Real-time syntax-colored JSON/SQL payloads.
4. **Telemetry HUD**: Displays active agent state, 18ms inference latency, and decision accuracy.
5. **Guided Video & Architecture Walkthrough**: 4-chapter interactive presentation with chapter scrubbing and auto-play.
6. **Model Tuning**: Interactive sliders for temperature, reasoning depth, and guardrails.

---

## 🎨 Design System & Architecture
- **Interactive Header Navigation**: `Home`, `About Us`, `Solutions`, `Industries`, `Projects`, `Why Us`, `Contact` with smooth-scrolling active indicators and scrollspy.
- **Dynamic Industry Switcher**: 8 industry tabs (`Customer Service`, `E-commerce`, `Healthcare`, `Finance`, `Manufacturing`, `Real Estate`, `Education`, `Logistics`) updating featured case study cards in real time.
- **Responsive & Mobile Ready**: Full drawer navigation menu and adaptive modal view for mobile devices.
- **Brand Colors**: Royal Electric Blue (`#0052FF`), Cyan (`#00C6FF`), and Deep Dark Navy (`#070D1E`).

